modName = "Noita Bingo"
-- all functions below are optional and can be left out 

--[[


function OnModPostInit()
	print("Mod - OnModPostInit()") -- Then this is called for all mods
end



function OnWorldInitialized() -- This is called once the game world is initialized. Doesn't ensure any world chunks actually exist. Use OnPlayerSpawned to ensure the chunks around player have been loaded or created.
	GamePrint( "OnWorldInitialized() " .. tostring(GameGetFrameNum()) )
end

function OnWorldPreUpdate() -- This is called every time the game is about to start updating the world
	GamePrint( "Pre-update hook " .. tostring(GameGetFrameNum()) )
end

function OnMagicNumbersAndWorldSeedInitialized() -- this is the last point where the Mod* API is available. after this materials.xml will be loaded.

end

]]--
dofile("mods/"..modName.."/files/enemy_kill_test.lua")
dofile("mods/"..modName.."/files/choose_tasks.lua")
dofile_once("data/scripts/lib/utilities.lua")
local EZMouse = dofile_once("mods/"..modName.."/files/EZMouse/EZMouse.lua")("mods/"..modName.."/files/EZMouse/")
widget = EZMouse.Widget({
  x = 100,
  y = 50,
  z = 10,
  width = 325,
  height = 325,
  draggable = true,
})

function all_list_to_int(list_thing)
	local inc = 0
	for _,i in ipairs(list_thing) do
		inc = inc + 1
		list_thing[inc] = tonumber(i)
	end
	return list_thing
end

function mysplit (inputstr, sep)
	local t={}
	for str in string.gmatch(inputstr, "([^"..sep.."]+)") do
		table.insert(t, str)
	end
	return t
end

function word_wrap( str, wrap_size )
    if wrap_size == nil then wrap_size = 11; end
    local last_space_index = 1;
    local last_wrap_index = 0;
    for i=1,#str do
        if str:sub(i,i) == " " then
            last_space_index = i;
        end
        if str:sub(i,i) == "\n" then
            last_space_index = i;
            last_wrap_index = i;
        end
        if i - last_wrap_index > wrap_size then
            str = str:sub(1,last_space_index-1) .. "," .. str:sub(last_space_index + 1);
            last_wrap_index = i;
        end
    end
    return str;
end

function has_bingo_line(board)
	-- Check rows
	for i = 1, 5 do
	  if board[(i - 1) * 5 + 1] and board[(i - 1) * 5 + 2] and board[(i - 1) * 5 + 3] and board[(i - 1) * 5 + 4] and board[(i - 1) * 5 + 5] then
		return true
	  end
	end
  
	-- Check columns
	for i = 1, 5 do
	  if board[i] and board[i + 5] and board[i + 10] and board[i + 15] and board[i + 20] then
		return true
	  end
	end
  
	-- Check diagonals
	if board[1] and board[7] and board[13] and board[19] and board[25] then
	  return true
	end
	if board[5] and board[9] and board[13] and board[17] and board[21] then
	  return true
	end
  
	-- No bingo found
	return false
end

function has_bingo_full(board)
	-- Check rows
	for i = 1, #board do
		if not board[i] then
			return false
		end
	end
	return true
end

function OnWorldInitialized()
	if not GameHasFlagRun("globals_init") then
		GameAddFlagRun("globals_init")
		GlobalsSetValue("tot_trick_kills",0)
		GlobalsSetValue("tot_gold_spent", 0)
		GlobalsSetValue("tot_things_bought", 0)
		GlobalsSetValue("tot_dam_taken", 0)
		GlobalsSetValue("bingo_yet", 0)
		local _,l,day,hour,minute,second = GameGetDateAndTimeUTC()
		local seconds = (day * 86400) + (hour * 3600) + (minute * 60) + second
		GlobalsSetValue("second_started",seconds)
	end
	if not (GlobalsGetValue("Im_gonna_cry") == "PLEASE NO") then
		GlobalsSetValue("Im_gonna_cry","PLEASE NO")
		GlobalsSetValue("curr_gold_glo",0)
		_G.objective_list = {}
		_G.objective_list_index = {}

		_G.biome_list = {}
		_G.biome_list_index = {}

		_G.perk_lists = {}
		_G.perk_lists_index = {}
		
		_G.boss_list = {}
		_G.boss_list_index = {}

		_G.status_lists = {}
		_G.status_lists_index = {}

		_G.kill_count = {}
		_G.kill_count_index = {}

		_G.gold_count = {}
		_G.gold_count_index = {}	

		_G.max_hp_count = {}
		_G.max_hp_count_index = {}

		_G.curr_hp_count = {}
		_G.curr_hp_count_index = {}

		_G.orb_number = {}
		_G.orb_number_index = {}

		--_G.death_message = {" | explosion"}
		_G.stat_list = {}
		_G.stat_list_index = {}

		_G.item_list = {}
		_G.item_list_index = {}

		_G.trick_kill_list = {}
		_G.trick_kill_list_index = {}

		_G.spell_lists = {}
		_G.spell_lists_index = {}

		_G.spent_list = {}
		_G.spent_list_index = {}

		_G.bought_list = {}
		_G.bought_list_index = {}
		
		_G.tot_dam_list = {}
		_G.tot_dam_list_index = {}

		_G.options_type = {}
		_G.options = {}

	else
		_G.objective_list = mysplit(GlobalsGetValue('objective_list_glo'), ",")
		_G.objective_list_index = all_list_to_int(mysplit(GlobalsGetValue('objective_list_index_glo'), ","))

		_G.biome_list = mysplit(GlobalsGetValue('biome_list_glo'), ",")
		_G.biome_list_index = all_list_to_int(mysplit(GlobalsGetValue('biome_list_index_glo'), ","))

		_G.perk_lists = mysplit(GlobalsGetValue('perk_lists_glo'), ",")
		_G.perk_lists_index = all_list_to_int(mysplit(GlobalsGetValue('perk_lists_index_glo'), ","))

		_G.boss_list = mysplit(GlobalsGetValue('boss_list_glo'), ",")
		_G.boss_list_index = all_list_to_int(mysplit(GlobalsGetValue('boss_list_index_glo'), ","))

		_G.status_lists = mysplit(GlobalsGetValue('status_lists_glo'), ",")
		_G.status_lists_index = all_list_to_int(mysplit(GlobalsGetValue('status_lists_index_glo'), ","))

		_G.kill_count = all_list_to_int(mysplit(GlobalsGetValue('kill_count_glo'), ","))
		_G.kill_count_index = all_list_to_int(mysplit(GlobalsGetValue('kill_count_index_glo'), ","))

		_G.gold_count = all_list_to_int(mysplit(GlobalsGetValue('gold_count_glo'), ","))
		_G.gold_count_index = all_list_to_int(mysplit(GlobalsGetValue('gold_count_index_glo'), ","))

		_G.max_hp_count = all_list_to_int(mysplit(GlobalsGetValue('max_hp_count_glo'), ","))
		_G.max_hp_count_index = all_list_to_int(mysplit(GlobalsGetValue('max_hp_count_index_glo'), ","))

		_G.curr_hp_count = all_list_to_int(mysplit(GlobalsGetValue('curr_hp_count_glo'), ","))
		_G.curr_hp_count_index = all_list_to_int(mysplit(GlobalsGetValue('curr_hp_count_index_glo'), ","))

		_G.orb_number = all_list_to_int(mysplit(GlobalsGetValue('orb_number_glo'), ","))
		_G.orb_number_index = all_list_to_int(mysplit(GlobalsGetValue('orb_number_index_glo'), ","))

		--_G.death_message = {" | explosion"}

		_G.stat_list = mysplit(GlobalsGetValue('stat_list_glo'), ",")
		_G.stat_list_index = all_list_to_int(mysplit(GlobalsGetValue('stat_list_index_glo'), ","))

		_G.item_list = {}
		_G.item_list_index = {}

		_G.trick_kill_list = all_list_to_int(mysplit(GlobalsGetValue('trick_kill_list_glo'), ","))
		_G.trick_kill_list_index = all_list_to_int(mysplit(GlobalsGetValue('trick_kill_list_index_glo'), ","))

		_G.spell_lists = mysplit(GlobalsGetValue('spell_lists_glo'), ",")
		_G.spell_lists_index = all_list_to_int(mysplit(GlobalsGetValue('spell_lists_index_glo'), ","))

		_G.spent_list = mysplit(GlobalsGetValue('spent_list_glo'), ",")
		_G.spent_list_index = all_list_to_int(mysplit(GlobalsGetValue('spent_list_index_glo'), ","))

		_G.bought_list = mysplit(GlobalsGetValue('bought_list_glo'), ",")
		_G.bought_list_index = all_list_to_int(mysplit(GlobalsGetValue('bought_list_index_glo'), ","))

		_G.tot_dam_list = mysplit(GlobalsGetValue('tot_dam_list_glo'), ",")
		_G.tot_dam_list_index = all_list_to_int(mysplit(GlobalsGetValue('tot_dam_list_index_glo'), ","))

		_G.options_type = mysplit(GlobalsGetValue('options_type_glo'), ",")
		_G.options = mysplit(GlobalsGetValue('options_glo'), ",")

	end
end

function OnPlayerSpawned( player_entity ) -- This runs when player entity has been created
	local player = EntityGetWithTag("player_unit")[1]
	local x, y = EntityGetTransform(player)
	if not GameHasFlagRun("create_board") then
		GameAddFlagRun("create_board")
		local difficulty = ModSettingGet('noita_bingo.difficulty_level')
		if difficulty == 'normal' then
			dofile("mods/"..modName.."/files/stuff_stuff/perk_stuff.lua")
			dofile( "mods/"..modName.."/files/stuff_stuff/status_stuff.lua")
			dofile("mods/"..modName.."/files/stuff_stuff/actions_stuff.lua")
		elseif difficulty == "hard" then
			dofile("mods/"..modName.."/files/stuff_stuff/perk_stuff_hard.lua")
			dofile( "mods/"..modName.."/files/stuff_stuff/status_stuff_hard.lua")
			dofile("mods/"..modName.."/files/stuff_stuff/actions_stuff_hard.lua")
		else
			dofile("mods/"..modName.."/files/stuff_stuff/perk_stuff_easy.lua")
			dofile( "mods/"..modName.."/files/stuff_stuff/status_stuff_easy.lua")
			dofile("mods/"..modName.."/files/stuff_stuff/actions_stuff_easy.lua")
		end
		open_board = 0
		_G.list_of_tiles_done = {false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false}
		rand_tasks(perk_lisp,status_effect_stuff,actions)
		_G.list_of_tiles = {tile_1,tile_2,tile_3,tile_4,tile_5,tile_6,tile_7,tile_8,tile_9,tile_10,tile_11,tile_12,tile_13,tile_14,tile_15,tile_16,tile_17,tile_18,tile_19,tile_20,tile_21,tile_22,tile_23,tile_24,tile_25}
		for i = 1, 25 do
			--_G.list_of_tiles_done[i] = true
			_G.list_of_tiles[i] = _G.options[i]
		end
		list_to_global(list_of_tiles,'list_of_tiles_glo')
		list_to_global(list_of_tiles_done,'list_of_tiles_done_glo')
		component_id = EntityAddComponent(player, "LuaComponent", {
			script_damage_received = "mods/"..modName.."/files/damage_received.lua",
			remove_after_executed = "0",
			execute_every_n_frame = "5"
		})
		EntitySetComponentIsEnabled(player, component_id, true)
	else
		open_board = 0
		_G.list_of_tiles = mysplit(GlobalsGetValue('list_of_tiles_glo'), ",")
		_G.list_of_tiles_done = mysplit(GlobalsGetValue('list_of_tiles_done_glo'), ",")
		local inc = 0
		for _,i in ipairs(_G.list_of_tiles_done) do
			inc = inc + 1
			if i == 'true' then
				list_of_tiles_done[inc] = true
			else
				list_of_tiles_done[inc] = false
			end
		end
	end

	--EntityLoad("data/entities/items/pickup/chest_random_super.xml", x, y)

	--EntityLoad("data/entities/animals/scorpion.xml", x, y)

	--EntityLoad("data/entities/items/pickup/beamstone.xml", x, y)

	--EntityLoad( "data/entities/animals/boss_centipede/boss_centipede.xml", x, y )

	--EntitySetTransform(player, 3450, 13100)
end

function OnWorldPreUpdate()
	gui = gui or GuiCreate()
	local difficulty = ModSettingGet('noita_bingo.difficulty_level')
	if difficulty == 'normal' then
		dofile("mods/"..modName.."/files/stuff_stuff/perk_stuff.lua")
		dofile( "mods/"..modName.."/files/stuff_stuff/status_stuff.lua")
		dofile("mods/"..modName.."/files/stuff_stuff/actions_stuff.lua")
	elseif difficulty == "hard" then
		dofile("mods/"..modName.."/files/stuff_stuff/perk_stuff_hard.lua")
		dofile( "mods/"..modName.."/files/stuff_stuff/status_stuff_hard.lua")
		dofile("mods/"..modName.."/files/stuff_stuff/actions_stuff_hard.lua")
	else
		dofile("mods/"..modName.."/files/stuff_stuff/perk_stuff_easy.lua")
		dofile( "mods/"..modName.."/files/stuff_stuff/status_stuff_easy.lua")
		dofile("mods/"..modName.."/files/stuff_stuff/actions_stuff_easy.lua")
	end
	
	local _id = 0
	local function id()
		_id = _id + 1
		return _id
	end

	if (open_board == 0) then
		string = "[Bingo]"
	else
		string = "[Close]"
	end
	GuiStartFrame( gui )
	local placement = ModSettingGet('noita_bingo.gui')
	if placement == "middle" then
		GuiLayoutBeginVertical(gui, 51 ,1)
	elseif placement == "right" then
		GuiLayoutBeginVertical(gui, 88 ,1)
	else
		GuiLayoutBeginVertical(gui, 10 ,1)
	end
	open_bingo = GuiButton(gui, id(), 0, 0, string)
	if tonumber(GlobalsGetValue("bingo_yet")) == 0 then
		if _G.list_of_tiles_done ~= nil then
			if ModSettingGet('noita_bingo.bingo_type') == 'line' then
				if has_bingo_line(_G.list_of_tiles_done) then
					GlobalsSetValue("bingo_yet",1)
					GamePrintImportant("BINGO!")
					local reward = ModSettingGet('noita_bingo.reward')
					local player = EntityGetWithTag("player_unit")[1]
					local x, y = EntityGetTransform(player)
					if reward == "great" then
						EntityLoad("data/entities/items/pickup/chest_random_super.xml", x, y)
					elseif reward == "chest" then
						EntityLoad("data/entities/items/pickup/chest_random.xml", x, y)
					elseif reward == "sun" then
						EntityLoad("data/entities/items/pickup/sun/newsun.xml", x, y-400)
					end
					local _,l,day,hour,minute,second = GameGetDateAndTimeUTC()
					local seconds =  (day * 86400) + (hour * 3600) + (minute * 60) + second
					GlobalsSetValue("end_time",seconds-GlobalsGetValue("second_started"))
				end
			else
				if has_bingo_full(_G.list_of_tiles_done) then
					GlobalsSetValue("bingo_yet",1)
					GamePrintImportant("BINGO!")
					local reward = ModSettingGet('noita_bingo.reward')
					local player = EntityGetWithTag("player_unit")[1]
					local x, y = EntityGetTransform(player)
					if reward == "great" then
						EntityLoad("data/entities/items/pickup/chest_random_super.xml", x, y)
					elseif reward == "chest" then
						EntityLoad("data/entities/items/pickup/chest_random.xml", x, y)
					elseif reward == "sun" then
						EntityLoad("data/entities/items/pickup/sun/newsun.xml", x, y-400)
					end
					local _,l,day,hour,minute,second = GameGetDateAndTimeUTC()
					local seconds =  (day * 86400) + (hour * 3600) + (minute * 60) + second
					GlobalsSetValue("end_time",seconds-GlobalsGetValue("second_started"))
				end
			end
		end
	end
	GuiLayoutEnd( gui )
	
	if open_bingo then
		if open_board == 1 then
			open_board = 0
		else
			open_board = 1
		end
	end
	if (open_board == 1) then
		gui_2 = gui_2 or GuiCreate()
		GuiStartFrame(gui_2)
		EZMouse.update(gui_2)
		GuiLayoutBeginVertical(gui, 0 ,0)
		GuiOptionsAddForNextWidget(gui, 2)
		GuiZSetForNextWidget( gui, 10 )
		GuiImage(gui, id(), widget.x+10, widget.y+10, "mods/"..modName.."/files/background.png", 0.5, 3, 0)
		GuiLayoutEnd( gui )
		GuiOptionsAddForNextWidget(gui, 2)
		GuiImage(gui, id(), widget.x+10, widget.y+10, "mods/"..modName.."/files/bingo_board_temp.png", 1, 3, 0)
		GuiLayoutBeginVertical(gui, 0 ,0)
		if tonumber(GlobalsGetValue("bingo_yet")) == 0 then
			local _,l,day,hour,minute,second = GameGetDateAndTimeUTC()
			local seconds =  (day * 86400) + (hour * 3600) + (minute * 60) + second
			GuiText(gui, widget.x+200, widget.y-3, seconds-GlobalsGetValue("second_started"))
		elseif tonumber(GlobalsGetValue("bingo_yet")) == 1 then
			GuiText(gui, widget.x+200, widget.y-3, "Bingo in: "..GlobalsGetValue("end_time").." seconds")
		end
		GuiLayoutEnd( gui )
		_G.list_of_tiles_done = mysplit(GlobalsGetValue('list_of_tiles_done_glo'), ",")
		local inc = 0
		for _,i in ipairs(_G.list_of_tiles_done) do
			inc = inc + 1
			if i == 'true' then
				list_of_tiles_done[inc] = true
			else
				list_of_tiles_done[inc] = false
			end
		end
		for i = 1, 5 do 
			for f = 1, 5 do
				GuiText(gui, (57*f)-34+widget.x, (57*i)-35+widget.y, tostring(_G.options_type[((i-1)*5)+f]))
				if (tostring(_G.options_type[((i-1)*5)+f]) == "Kill") or (tostring(_G.options_type[((i-1)*5)+f]) == "Kill ") then
					GuiLayoutBeginVertical(gui, 0 ,0)
					GuiImage(gui, id(), (57*f)-29+widget.x, (57*i)-22+widget.y, "data/ui_gfx/animal_icons/".._G.list_of_tiles[((i-1)*5)+f]..".png", 1, 2, 0)
					if (tostring(_G.options_type[((i-1)*5)+f]) == "Kill ") then
						GuiTooltip( gui, "Objective done?: "..tostring(_G.list_of_tiles_done[((i-1)*5)+f]), "Kill boss: "..GameTextGetTranslatedOrNot("$animal_".._G.list_of_tiles[((i-1)*5)+f]).." (".._G.list_of_tiles[((i-1)*5)+f]..")")
					else
						GuiTooltip( gui, "Objective done?: "..tostring(_G.list_of_tiles_done[((i-1)*5)+f]), "Kill enemy: "..GameTextGetTranslatedOrNot("$animal_".._G.list_of_tiles[((i-1)*5)+f]).." (".._G.list_of_tiles[((i-1)*5)+f]..")")
					end
					GuiLayoutEnd( gui )
				elseif (tostring(_G.options_type[((i-1)*5)+f]) == "Get perk") then
					GuiLayoutBeginVertical(gui, 0 ,0)
					GuiImage(gui, id(), (57*f)-26+widget.x, (57*i)-22+widget.y, perk_lisp[tonumber(_G.list_of_tiles[((i-1)*5)+f])].perk_icon, 1, 2, 0)
					GuiTooltip( gui, "Objective done?: "..tostring(_G.list_of_tiles_done[((i-1)*5)+f]), "Get perk: "..GameTextGetTranslatedOrNot(perk_lisp[tonumber(_G.list_of_tiles[((i-1)*5)+f])].ui_name))
					GuiLayoutEnd( gui )
				elseif (tostring(_G.options_type[((i-1)*5)+f]) == "Get stain") then
					GuiLayoutBeginVertical(gui, 0 ,0)
					GuiImage(gui, id(), (57*f)-26+widget.x, (57*i)-22+widget.y, status_effect_stuff[tonumber(_G.list_of_tiles[((i-1)*5)+f])].ui_icon, 1, 2, 0)
					GuiTooltip( gui, "Objective done?: "..tostring(_G.list_of_tiles_done[((i-1)*5)+f]), "Get stain: "..GameTextGetTranslatedOrNot(status_effect_stuff[tonumber(_G.list_of_tiles[((i-1)*5)+f])].ui_name).." ("..status_effect_stuff[tonumber(_G.list_of_tiles[((i-1)*5)+f])].id..")")
					GuiLayoutEnd( gui )
				elseif (tostring(_G.options_type[((i-1)*5)+f]) == "Get") then
					GuiText(gui, (57*f)-34+widget.x, (57*i)-26+widget.y, _G.list_of_tiles[((i-1)*5)+f].." kills")
					GuiLayoutBeginVertical(gui, 0 ,0)
					GuiImage(gui, id(), (57*f)-34+widget.x, (57*i)-33+widget.y,"mods/"..modName.."/files/empty.png", 1, 2, 0)
					GuiTooltip( gui, "Objective done?: "..tostring(_G.list_of_tiles_done[((i-1)*5)+f]), "Get # enemy kills: "..StatsGetValue("enemies_killed").."/".._G.list_of_tiles[((i-1)*5)+f])
					GuiLayoutEnd( gui )
				elseif (tostring(_G.options_type[((i-1)*5)+f]) == "Have at least") then
					GuiText(gui, (57*f)-34+widget.x, (57*i)-26+widget.y, _G.list_of_tiles[((i-1)*5)+f].." gold")
					GuiLayoutBeginVertical(gui, 0 ,0)
					GuiImage(gui, id(), (57*f)-34+widget.x, (57*i)-33+widget.y,"mods/"..modName.."/files/empty.png", 1, 2, 0)
					GuiTooltip( gui, "Objective done?: "..tostring(_G.list_of_tiles_done[((i-1)*5)+f]), "Get # gold: "..GlobalsGetValue("curr_gold_glo").."/".._G.list_of_tiles[((i-1)*5)+f])
					GuiLayoutEnd( gui )
				elseif (tostring(_G.options_type[((i-1)*5)+f]) == "Have at least ") then
					GuiText(gui, (57*f)-34+widget.x, (57*i)-26+widget.y, _G.list_of_tiles[((i-1)*5)+f].." max hp")
					GuiLayoutBeginVertical(gui, 0 ,0)
					GuiImage(gui, id(), (57*f)-34+widget.x, (57*i)-33+widget.y,"mods/"..modName.."/files/empty.png", 1, 2, 0)
					GuiTooltip( gui, "Objective done?: "..tostring(_G.list_of_tiles_done[((i-1)*5)+f]), "Get # max hp: "..GlobalsGetValue("gui_stuff_for_max_hp").."/".._G.list_of_tiles[((i-1)*5)+f])
					GuiLayoutEnd( gui )
				elseif (tostring(_G.options_type[((i-1)*5)+f]) == "Have exactly") then
					GuiLayoutBeginVertical(gui, 0 ,0)
					GuiText(gui, (57*f)-34+widget.x, (57*i)-26+widget.y, _G.list_of_tiles[((i-1)*5)+f].." health")
					GuiLayoutEnd( gui )
				elseif (tostring(_G.options_type[((i-1)*5)+f]) == "Have exactly") then
					GuiLayoutBeginVertical(gui, 0 ,0)
					GuiText(gui, (57*f)-34+widget.x, (57*i)-26+widget.y, _G.list_of_tiles[((i-1)*5)+f].." health")
					GuiLayoutEnd( gui )
				elseif (tostring(_G.options_type[((i-1)*5)+f]) == "Get ") then
					GuiText(gui, (57*f)-34+widget.x, (57*i)-26+widget.y, _G.list_of_tiles[((i-1)*5)+f].." orbs")
					GuiLayoutBeginVertical(gui, 0 ,0)
					GuiImage(gui, id(), (57*f)-34+widget.x, (57*i)-33+widget.y,"mods/"..modName.."/files/empty.png", 1, 2, 0)
					GuiTooltip( gui, "Objective done?: "..tostring(_G.list_of_tiles_done[((i-1)*5)+f]), "Get # orbs: "..GameGetOrbCountThisRun().."/".._G.list_of_tiles[((i-1)*5)+f])
					GuiLayoutEnd( gui )
				elseif (tostring(_G.options_type[((i-1)*5)+f]) == "Held wand:") then
					local temp_name = mysplit(_G.list_of_tiles[((i-1)*5)+f],"|")
					local print_thing = ''
					if temp_name[1] == "spellscast" then
						print_thing = print_thing.."Spells cast "
					elseif temp_name[1] == "castdelay" then
						print_thing = print_thing.."Cast delay "
					elseif temp_name[1] == "rechargetime" then
						print_thing = print_thing.."Rechg. time "
					elseif temp_name[1] == "manamax" then
						print_thing = print_thing.."Max mana "
					elseif temp_name[1] == "maxchargespeed" then
						print_thing = print_thing.."Mana charge speed "
					else
						print_thing = print_thing.."Capacity "
					end
					if temp_name[2] == ">" then
						print_thing = print_thing.."is greater than "
					else
						print_thing = print_thing.."is less than "
					end
					if (temp_name[1] == "castdelay" or temp_name[1] == "rechargetime") then
						print_thing = print_thing..tostring(tonumber(temp_name[3])/100)
					else
						print_thing = print_thing..temp_name[3]
					end
					local final_local_variable = mysplit(word_wrap(print_thing),",")
					for h = 1,#final_local_variable do
						GuiText(gui, (57*f)-34+widget.x, (57*i)-26+widget.y+((h-1)*10), final_local_variable[h] )
					end
				elseif (tostring(_G.options_type[((i-1)*5)+f]) == "Get  ") then
					GuiText(gui, (57*f)-34+widget.x, (57*i)-26+widget.y, _G.list_of_tiles[((i-1)*5)+f].." trick")
					GuiText(gui, (57*f)-36+widget.x, (57*i)-16+widget.y, " kills")
					GuiLayoutBeginVertical(gui, 0 ,0)
					GuiImage(gui, id(), (57*f)-34+widget.x, (57*i)-33+widget.y,"mods/"..modName.."/files/empty.png", 1, 2, 0)
					GuiTooltip( gui, "Objective done?: "..tostring(_G.list_of_tiles_done[((i-1)*5)+f]), "Get # trick kills: "..GlobalsGetValue("tot_trick_kills").."/".._G.list_of_tiles[((i-1)*5)+f])
					GuiLayoutEnd( gui )
				elseif (tostring(_G.options_type[((i-1)*5)+f]) == "Cast spell") then
					GuiLayoutBeginVertical(gui, 0 ,0)
					GuiImage(gui, id(), (57*f)-29+widget.x, (57*i)-22+widget.y, actions[tonumber(_G.list_of_tiles[((i-1)*5)+f])].sprite, 1, 2, 0)
					GuiTooltip( gui, "Objective done?: "..tostring(_G.list_of_tiles_done[((i-1)*5)+f]), "Cast spell: "..GameTextGetTranslatedOrNot(actions[tonumber(_G.list_of_tiles[((i-1)*5)+f])].name))
					GuiLayoutEnd( gui )
				elseif (tostring(_G.options_type[((i-1)*5)+f]) == "Spend") then
					GuiText(gui, (57*f)-34+widget.x, (57*i)-26+widget.y, _G.list_of_tiles[((i-1)*5)+f].." gold")
					GuiLayoutBeginVertical(gui, 0 ,0)
					GuiImage(gui,id(), (57*f)-34+widget.x, (57*i)-33+widget.y,"mods/"..modName.."/files/empty.png", 1, 2, 0)
					GuiTooltip( gui, "Objective done?: "..tostring(_G.list_of_tiles_done[((i-1)*5)+f]), "Spend # gold: "..GlobalsGetValue("tot_gold_spent").."/".._G.list_of_tiles[((i-1)*5)+f])
					GuiLayoutEnd( gui )
				elseif (tostring(_G.options_type[((i-1)*5)+f]) == "Buy") then
					GuiText(gui, (57*f)-34+widget.x, (57*i)-26+widget.y, _G.list_of_tiles[((i-1)*5)+f].." items")
					GuiLayoutBeginVertical(gui, 0 ,0)
					GuiImage(gui, id(), (57*f)-34+widget.x, (57*i)-33+widget.y,"mods/"..modName.."/files/empty.png", 1, 2, 0)
					GuiTooltip( gui, "Objective done?: "..tostring(_G.list_of_tiles_done[((i-1)*5)+f]), "Buy # items: "..GlobalsGetValue("tot_things_bought").."/".._G.list_of_tiles[((i-1)*5)+f])
					GuiLayoutEnd( gui )
				elseif (tostring(_G.options_type[((i-1)*5)+f]) == "Take") or (tostring(_G.options_type[((i-1)*5)+f]) == "Take under")then
					GuiText(gui, (57*f)-34+widget.x, (57*i)-26+widget.y, _G.list_of_tiles[((i-1)*5)+f].." total")
					GuiText(gui, (57*f)-34+widget.x, (57*i)-16+widget.y, "damage")
					GuiLayoutBeginVertical(gui, 0 ,0)
					GuiImage(gui,id(), (57*f)-34+widget.x, (57*i)-33+widget.y,"mods/"..modName.."/files/empty.png", 1, 2, 0)
					GuiTooltip( gui, "Objective done?: "..tostring(_G.list_of_tiles_done[((i-1)*5)+f]), tostring(_G.options_type[((i-1)*5)+f]).." # total damage: "..math.floor(tonumber(GlobalsGetValue("tot_dam_taken"))+0.9999).."/".._G.list_of_tiles[((i-1)*5)+f])
					GuiLayoutEnd( gui )
				else
					local temp_name = mysplit(word_wrap(GameTextGetTranslatedOrNot(tostring(_G.list_of_tiles[((i-1)*5)+f]))),",")
					for h = 1,#temp_name do
						GuiText(gui, (57*f)-34+widget.x, (57*i)-26+widget.y+((h-1)*10), temp_name[h] )
					end
				end
				if (_G.list_of_tiles_done[((i-1)*5)+f] == true) then
					GuiLayoutBeginVertical(gui, 0 ,0)
					GuiZSetForNextWidget( gui, -10 )
					GuiImage(gui, id(), (57*f)-35+widget.x, (57*i)-35+widget.y, "mods/"..modName.."/files/tile_done.png", 1, 3, 0)
					GuiLayoutEnd( gui )
				end
			end
		end
	end
end

function OnWorldPostUpdate() -- This is called every time the game has finished updating the world
	if #_G.objective_list ~= nil then
		if #_G.objective_list > 0 then enemy_names_killed_check(_G.list_of_tiles_done,_G.objective_list,_G.objective_list_index) end
		if #_G.biome_list > 0 then moved_into_biome(_G.list_of_tiles_done,_G.biome_list,_G.biome_list_index) end
		if #_G.perk_lists > 0 then picked_up_perk(_G.list_of_tiles_done,_G.perk_lists,_G.perk_lists_index) end
		if #_G.boss_list > 0 then killed_boss(_G.list_of_tiles_done,_G.boss_list,_G.boss_list_index) end
		if #_G.status_lists > 0 then has_status(_G.list_of_tiles_done,_G.status_lists,_G.status_lists_index) end
		if #_G.kill_count > 0 then total_kills_equal(_G.list_of_tiles_done,_G.kill_count,_G.kill_count_index) end
		if #_G.gold_count > 0 then total_gold_equal(_G.list_of_tiles_done,_G.gold_count,_G.gold_count_index) end
		if #_G.max_hp_count > 0 then max_health_equals(_G.list_of_tiles_done,_G.max_hp_count,_G.max_hp_count_index,"max_hp") end
		if #_G.curr_hp_count > 0 then max_health_equals(_G.list_of_tiles_done,_G.curr_hp_count,_G.curr_hp_count_index,'hp') end
		if #_G.orb_number > 0 then orb_count_equal(_G.list_of_tiles_done,_G.orb_number,_G.orb_number_index) end
		--if #death_message > 0 then if_killed_by(death_message) end
		if #_G.stat_list > 0 then if_wand_has_stats(_G.list_of_tiles_done,_G.stat_list,_G.stat_list_index) end

		if #item_list > 0 then if_item_found(item_list) end
		if #_G.trick_kill_list > 0 then num_trick_kills(_G.list_of_tiles_done,_G.trick_kill_list,_G.trick_kill_list_index) end

	end
end

-- This code runs when all mods' filesystems are registered


--print("Example mod init done")