dofile_once("data/scripts/lib/utilities.lua")
dofile( "data/scripts/perks/perk.lua")
dofile( "data/scripts/gun/gun_actions.lua" )
---------------------------------------------------
function list_to_global(list_name,global_name)
	local placeholder = ""
	for _,i in ipairs(list_name) do
		placeholder = placeholder..tostring(i)..","
	end
	GlobalsSetValue(global_name,placeholder)
end

function randomize_list(list_name)
	local temp_list = {}
	while #list_name > 0 do
		local random_index = Random(#list_name)
		table.insert(temp_list, list_name[random_index])
		table.remove(list_name, random_index)
	end
	return(temp_list)
end

function rand_tasks(perk_list,status_effect_list,actions)
	
	local difficulty = ModSettingGet('noita_bingo.difficulty_level')
	if difficulty == "hard" then
		biome_list_me = {"clouds", "crypt", "desert", "dragoncave", "fungicave", "lake", "lava", "pyramid", 'rainforest', "sandcave", "snowcave", "vault", "boss_arena", "snowcastle", "winter","gold"}

		enemy_list = {'acidshooter', 'alchemist', 'ant', 'assassin', 'barfer', 'bat', 'bigbat', 'bigfirebug', 'bigzombie', 'blob', 'bloom', 'coward', 'crystal_physics', 'drone_lasership', 'deer', 'enlightened_alchemist', 'failed_alchemist', 'duck', 'elk', 'firebug', 'firemage', 'firemage_weak', 'fireskull', 'fish', 'flamer', 'fly', 'frog', 'frog_big', 'fungus', 'fungus_big', 'gazer', 'ghost', 'ghoul', 'giant', 'giantshooter', 'goblin_bomb', 'lasershooter', 'lukki_tiny', 'miner_fire', 'necromancer_shop', 'icer', 'iceskull', 'maggot', 'miniblob', 'missilecrab', 'monk', 'necromancer', 'pebble_physics', 'phantom_a', 'phantom_b', 'scavenger_clusterbomb','scavenger_grenade', 'scavenger_heal', 'scavenger_leader', 'scavenger_mine', 'scavenger_poison', 'scavenger_smg', 'roboguard', 'scorpion', 'shaman', "sheep", 'shooterflower', 'skullfly', 'skullrat', 'skygazer', 'sniper', 'spearbot', 'spitmonster', 'tank', 'tank_rocket', 'tentacler', 'tentacler_small', 'thundermage','thunderskull', 'wizard_dark', 'wizard_hearty', 'wizard_neutral', 'wizard_poly', 'wizard_returner', 'wizard_swapper', 'wizard_tele', 'wizard_twitchy', 'wizard_weaken', 'worm', 'worm_big', 'worm_tiny', 'wraith', 'wraith_glowing'}

		--local item_list_me = {'egg_slime', 'egg_worm', 'egg_fire', 'egg_purple', 'bloodmoney_50', 'bloodmoney_200', 'goldnugget_50', 'goldnugget_200', 'heart', 'heart_fullhp', 'physics_die', 'thunderstone', 'broken_wand', 'moon', 'runestone_laser', 'runestone_fireball', 'runestone_lava', 'runestone_disc', 'runestone_null', 'runestone_slow', 'brimstone'}

		all_names = {"Go to","Kill","Get perk","Get stain",'Held wand:','Cast spell',"Kill "}
		
		boss_list_me = {'boss_alchemist','boss_centipede','boss_limbs','boss_pit','maggot_tiny','boss_wizard','boss_ghost'}

		wand_stat_list = {'spellscast','castdelay','rechargetime','manamax','maxchargespeed','capacity'}
	elseif difficulty == "normal" then
		biome_list_me = {"crypt", "desert", "dragoncave", "fungicave", "lake", "pyramid", 'rainforest', "sandcave", "snowcave", "vault", "boss_arena", "coalmine_alt", "excavationsite", "snowcastle", "winter"}

		enemy_list = {'acidshooter', 'alchemist', 'ant', 'assassin', 'barfer', 'bat', 'bigbat', 'bigfirebug', 'bigzombie', 'blob', 'bloom', 'coward', 'crystal_physics', 'drone_lasership', 'deer', 'enlightened_alchemist', 'failed_alchemist', 'elk', 'firebug', 'firemage', 'firemage_weak', 'fireskull', 'fish', 'flamer', 'fly', 'frog', 'frog_big', 'fungus', 'fungus_big', 'ghoul', 'giant', 'giantshooter', 'goblin_bomb', 'lasershooter', 'longleg', 'lukki_longleg', 'lukki_tiny', 'miner_fire', 'miner_weak', 'necromancer_shop', 'icer', 'iceskull', 'maggot', 'miner', 'miniblob', 'missilecrab', 'monk', 'necromancer', 'pebble_physics', 'phantom_a', 'phantom_b', 'scavenger_clusterbomb','scavenger_grenade', 'scavenger_heal', 'scavenger_leader', 'scavenger_mine', 'scavenger_poison', 'scavenger_smg', 'rat', 'roboguard', 'scorpion', 'shaman', 'shooterflower', 'shotgunner', 'skullfly', 'skullrat', 'slimeshooter', 'sniper', 'spearbot', 'spitmonster', 'tank', 'tank_rocket', 'tentacler', 'tentacler_small', 'thundermage','thunderskull', 'wizard_dark', 'wizard_hearty', 'wizard_neutral', 'wizard_poly', 'wizard_returner', 'wizard_swapper', 'wizard_tele', 'wizard_twitchy', 'wizard_weaken', 'worm', 'worm_big', 'worm_tiny', 'wraith', 'zombie', 'wraith_glowing'}

		--local item_list_me = {'egg_slime', 'egg_worm', 'egg_fire', 'egg_purple', 'bloodmoney_50', 'bloodmoney_200', 'goldnugget_50', 'goldnugget_200', 'heart', 'heart_fullhp', 'physics_die', 'thunderstone', 'broken_wand', 'moon', 'runestone_laser', 'runestone_fireball', 'runestone_lava', 'runestone_disc', 'runestone_null', 'runestone_slow', 'brimstone'}

		all_names = {"Go to","Kill","Get perk","Get stain",'Held wand:','Cast spell'}
		
		boss_list_me = {'boss_alchemist','boss_centipede','boss_limbs','boss_pit'}

		wand_stat_list = {'spellscast','castdelay','rechargetime','manamax','maxchargespeed','capacity'}
	else
		biome_list_me = {"crypt", "desert", "dragoncave", "fungicave", "lake", "pyramid", 'rainforest', "vault", "boss_arena", "coalmine_alt", "excavationsite", "snowcastle", "winter"}

		enemy_list = {'acidshooter', 'ant', 'assassin', 'barfer', 'bat', 'bigbat', 'bigfirebug', 'bigzombie', 'blob', 'bloom', 'coward', 'crystal_physics', 'drone_lasership', 'deer', 'firebug', 'firemage', 'firemage_weak', 'fireskull', 'fish', 'flamer', 'fly', 'frog', 'frog_big', 'fungus', 'ghoul', 'giant', 'giantshooter', 'goblin_bomb', 'lasershooter', 'longleg', 'lukki_longleg', 'lukki_tiny', 'miner_fire', 'miner_weak', 'icer', 'iceskull', 'maggot', 'miner', 'miniblob', 'missilecrab', 'monk', 'necromancer', 'pebble_physics', 'scavenger_clusterbomb','scavenger_grenade', 'scavenger_heal', 'scavenger_leader', 'scavenger_mine', 'scavenger_poison', 'scavenger_smg', 'rat', 'roboguard', 'scorpion', 'shaman', 'shooterflower', 'shotgunner', 'skullfly', 'skullrat', 'slimeshooter', 'sniper', 'spearbot', 'spitmonster', 'tank', 'tank_rocket', 'tentacler', 'tentacler_small', 'thundermage','thunderskull', 'wizard_dark', 'wizard_hearty', 'wizard_neutral', 'wizard_returner', 'wizard_swapper', 'wizard_tele', 'wizard_twitchy', 'wizard_weaken', 'worm', 'worm_tiny', 'wraith', 'zombie', 'wraith_glowing'}

		--local item_list_me = {'egg_slime', 'egg_worm', 'egg_fire', 'egg_purple', 'bloodmoney_50', 'bloodmoney_200', 'goldnugget_50', 'goldnugget_200', 'heart', 'heart_fullhp', 'physics_die', 'thunderstone', 'broken_wand', 'moon', 'runestone_laser', 'runestone_fireball', 'runestone_lava', 'runestone_disc', 'runestone_null', 'runestone_slow', 'brimstone'}

		all_names = {"Go to","Kill","Get perk","Get stain",'Held wand:','Cast spell'}
		
		boss_list_me = {'boss_alchemist','boss_centipede','boss_limbs','boss_pit'}

		wand_stat_list = {'spellscast','castdelay','rechargetime','manamax','maxchargespeed','capacity'}
	end

	local stupid_list_status = {}

	local stupid_list_perk = {}

	local stupid_list_spell = {}
	if difficulty == "easy" then
		for i = 1,3 do
			table.insert(_G.options_type, "Go to")
		end
		for i = 1,3 do
			table.insert(_G.options_type, "Kill")
		end
		for i = 1,1 do
			table.insert(_G.options_type, "Get perk")
		end
		for i = 1,3 do
			table.insert(_G.options_type, "Get stain")
		end
		for i = 1,1 do
			table.insert(_G.options_type, "Cast spell")
		end
		table.insert(_G.options_type, "Get")
		table.insert(_G.options_type, "Have at least")
		table.insert(_G.options_type, "Have at least ")
		table.insert(_G.options_type, "Have exactly")
		table.insert(_G.options_type, "Get ")
		table.insert(_G.options_type, "Held wand:")
		table.insert(_G.options_type, "Get  ")
		table.insert(_G.options_type, "Spend")
		table.insert(_G.options_type, "Buy")
		local rand = Random(1,2)
		if rand == 1 then
			table.insert(_G.options_type, "Take")
			table.insert(_G.options_type, "Kill ")
		else
			table.insert(_G.options_type, "Take under")
		end
	else
		for i = 1,2 do
			table.insert(_G.options_type, "Go to")
		end
		for i = 1,3 do
			table.insert(_G.options_type, "Kill")
		end
		for i = 1,2 do
			table.insert(_G.options_type, "Get perk")
		end
		for i = 1,2 do
			table.insert(_G.options_type, "Get stain")
		end
		for i = 1,2 do
			table.insert(_G.options_type, "Cast spell")
		end
		table.insert(_G.options_type, "Kill ")
		table.insert(_G.options_type, "Get")
		table.insert(_G.options_type, "Have at least")
		table.insert(_G.options_type, "Have at least ")
		table.insert(_G.options_type, "Have exactly")
		table.insert(_G.options_type, "Get ")
		table.insert(_G.options_type, "Held wand:")
		table.insert(_G.options_type, "Get  ")
		table.insert(_G.options_type, "Spend")
		table.insert(_G.options_type, "Buy")
		local rand = Random(1,2)
		if rand == 1 then
			table.insert(_G.options_type, "Take")
		else
			table.insert(_G.options_type, "Take under")
		end
	end
	for i = #_G.options_type,24 do
		local rand = Random(1, #all_names)
		table.insert(_G.options_type, all_names[rand])
	end

	_G.options_type = randomize_list(_G.options_type)
	for i = 1, 25 do
		if (_G.options_type[i] == "Go to") then
			local rand = Random(1, #biome_list_me)
			local biome_name = "$biome_"..biome_list_me[rand]
			table.insert(_G.options, biome_name)
			table.insert(_G.biome_list, biome_name)
			table.insert(_G.biome_list_index, i)
			table.remove(biome_list_me, rand)

		elseif (_G.options_type[i] == "Kill") then
			local rand = Random(1, #enemy_list)
			local enemy_name = "$animal_"..enemy_list[rand]
			table.insert(_G.options, enemy_list[rand])
			table.insert(_G.objective_list, enemy_name)
			table.insert(_G.objective_list_index, i)
			table.remove(enemy_list, rand)
		
		elseif (_G.options_type[i] == "Kill ") then
			local rand = Random(1, #boss_list_me)
			local enemy_name = "$animal_"..boss_list_me[rand]
			table.insert(_G.options, boss_list_me[rand])
			table.insert(_G.boss_list, enemy_name)
			table.insert(_G.boss_list_index, i)
			table.remove(boss_list_me, rand)

		elseif (options_type[i] == "Cast spell") then
			local test_var = true
			while test_var do
				test_var = false
				rand = Random(1, #actions)
				for _,i in ipairs(stupid_list_spell) do
					if i == rand then
						test_var = true
						break
					end
				end
			end
			table.insert(_G.options, rand)
			table.insert(_G.spell_lists, actions[rand].name)
			table.insert(_G.spell_lists_index, i)
			table.insert(stupid_list_spell, rand)

		elseif (options_type[i] == "Held wand:") then
			local rand = Random(1, #wand_stat_list)
			local which_stat = wand_stat_list[rand]
			table.remove(wand_stat_list,rand)
			if which_stat == "spellscast" or which_stat == "capacity" or which_stat == "maxchargespeed"then
				greater_or_less = ">"
				if which_stat == "spellscast" then
					if difficulty == "hard" then
						rand_stat = Random(4,12)
					elseif difficulty == "normal" then
						rand_stat = Random(3,8)
					else
						rand_stat = Random(2,6)
					end
				elseif which_stat == "maxchargespeed" then
					if difficulty == "hard" then
						rand_stat = Random(40,120)*10
					elseif difficulty == "normal" then
						rand_stat = Random(30,90)*10
					else
						rand_stat = Random(20,70)*10
					end
				else
					if difficulty == "hard" then
						rand_stat = Random(10,20)
					elseif difficulty == "normal" then
						rand_stat = Random(8,16)
					else
						rand_stat = Random(6,12)
					end
				end
			else
				local rand = Random(1,2)
				if rand == 1 then
					greater_or_less = ">"
					if which_stat == "castdelay" then
						if difficulty == "hard" then
							rand_stat = Random(50,90)
						elseif difficulty == "normal" then
							rand_stat = Random(40,70)
						else
							rand_stat = Random(30,60)
						end
					elseif which_stat == "rechargetime" then
						if difficulty == "hard" then
							rand_stat = Random(150,250)
						elseif difficulty == "normal" then
							rand_stat = Random(100,200)
						else
							rand_stat = Random(70,150)
						end
					elseif which_stat == "manamax" then
						if difficulty == "hard" then
							rand_stat = Random(100,250)*10
						elseif difficulty == "normal" then
							rand_stat = Random(70,200)*10
						else
							rand_stat = Random(40,150)*10
						end
					end
				else
					greater_or_less = "<"
					if which_stat == "castdelay" then
						if difficulty == "hard" then
							rand_stat = Random(0,8)
						elseif difficulty == "normal" then
							rand_stat = Random(1,8)
						else
							rand_stat = Random(3,8)
						end
					elseif which_stat == "rechargetime" then
						if difficulty == "hard" then
							rand_stat = Random(0,8)
						elseif difficulty == "normal" then
							rand_stat = Random(3,8)
						else
							rand_stat = Random(5,10)
						end
					elseif which_stat == "manamax" then
						if difficulty == "hard" then
							rand_stat = Random(51,75)
						elseif difficulty == "normal" then
							rand_stat = Random(55,80)
						else
							rand_stat = Random(60,85)
						end
					end
				end
			end
			local total_task = which_stat.."|"..greater_or_less.."|"..rand_stat
			table.insert(_G.options, total_task)
			table.insert(_G.stat_list, total_task)
			table.insert(_G.stat_list_index, i)

		elseif (options_type[i] == "Get stain") then
			local test_var = true
			while test_var do
				test_var = false
				rand = Random(1, #status_effect_list)
				for _,i in ipairs(stupid_list_status) do
					if i == rand then
						test_var = true
						break
					end
				end
			end
			table.insert(_G.options, rand)
			table.insert(_G.status_lists, status_effect_list[rand].id)
			table.insert(_G.status_lists_index, i)
			table.insert(stupid_list_status, rand)

		elseif (options_type[i] == "Get perk") then
			local test_var = true
			while test_var do
				test_var = false
				rand = Random(1, #perk_list)
				for _,i in ipairs(stupid_list_perk) do
					if i == rand then
						test_var = true
						break
					end
				end
			end
			table.insert(_G.options, rand)
			table.insert(_G.perk_lists, perk_list[rand].id)
			table.insert(_G.perk_lists_index, i)
			table.insert(stupid_list_perk, rand)

		elseif (options_type[i] == "Spend") then
			if difficulty == "hard" then
				rand = Random(10,100)*100
			elseif difficulty == "normal" then
				rand = Random(5,35)*100
			else
				rand = Random(1,15)*100
			end
			table.insert(_G.options, rand)
			table.insert(_G.spent_list, rand)
			table.insert(_G.spent_list_index, i)
		
		elseif (options_type[i] == "Buy") then
			if difficulty == "hard" then
				rand = Random(10,50)
			elseif difficulty == "normal" then
				rand = Random(5,30)
			else
				rand = Random(2,10)
			end
			table.insert(_G.options, rand)
			table.insert(_G.bought_list, rand)
			table.insert(_G.bought_list_index, i)

		elseif (options_type[i] == "Get") then
			if difficulty == "hard" then
				rand = Random(10,30)*10
			elseif difficulty == "normal" then
				rand = Random(33,150)
			else
				rand = Random(10,80)
			end
			table.insert(_G.options, rand)
			table.insert(_G.kill_count, rand)
			table.insert(_G.kill_count_index, i)
		elseif (options_type[i] == "Have at least") then
			if difficulty == "hard" then
				rand = Random(20,100)*100
			elseif difficulty == "normal" then
				rand = Random(5,25)*100
			else
				rand = Random(1,10)*100
			end
			table.insert(_G.options, rand)
			table.insert(_G.gold_count, rand)
			table.insert(_G.gold_count_index, i)
		elseif (options_type[i] == "Have at least ") then
			if difficulty == "hard" then
				rand = Random(20,50)*10
			elseif difficulty == "normal" then
				rand = Random(15,25)*10
			else
				rand = Random(11,17)*10
			end
			table.insert(_G.options, rand)
			table.insert(_G.max_hp_count, rand)
			table.insert(_G.max_hp_count_index, i)
		elseif (options_type[i] == "Have exactly") then
			local rand2 = Random(1,2)
			if difficulty == "hard" then
				if rand2 == 1 then
					rand = Random(1,10)
				else
					rand = Random(150,300)
				end
			elseif difficulty == "normal" then
				if rand2 == 1 then
					rand = Random(10,50)
				else
					rand = Random(101,150)
				end
			else
				rand = Random(10,99)
			end
			table.insert(_G.options, rand)
			table.insert(_G.curr_hp_count, rand)
			table.insert(_G.curr_hp_count_index, i)
		elseif (options_type[i] == "Get ") then
			num = Random(1,100)
			if difficulty == "hard" then
				if num < 60 then
					num = Random(2, 5)
				elseif num < 70 then
					num = 1
				else
					num = Random(6, 10)
				end
			elseif difficulty == "normal" then
				if num < 70 then
					num = Random(2, 4)
				elseif num < 90 then
					num = 1
				else
					num = Random(5, 8)
				end
			else
				if num < 60 then
					num = Random(2, 3)
				elseif num < 95 then
					num = 1
				else
					num = Random(3, 6)
				end
			end
			table.insert(_G.options, num)
			table.insert(_G.orb_number, num)
			table.insert(_G.orb_number_index, i)
		elseif (options_type[i] == "Get  ") then
			if difficulty == "hard" then
				rand = Random(10,30)*10
			elseif difficulty == "normal" then
				rand = Random(6,20)*10
			else
				rand = Random(25,75)
			end
			table.insert(_G.options, rand)
			table.insert(_G.trick_kill_list, rand)
			table.insert(_G.trick_kill_list_index, i)
		elseif (options_type[i] == "Take") then
			if difficulty == "hard" then
				rand = Random(30,75)*10
			elseif difficulty == "normal" then
				rand = Random(20,50)*10
			else
				rand = Random(10,25)*10
			end
			table.insert(_G.options, rand)
			table.insert(_G.tot_dam_list, rand)
			table.insert(_G.tot_dam_list_index, i)
		elseif (options_type[i] == "Take under") then
			if difficulty == "hard" then
				rand = Random(1,150)
			elseif difficulty == "normal" then
				rand = Random(70,25)*10
			else
				rand = Random(15,50)*10
			end
			_G.list_of_tiles_done[i] = true
			table.insert(_G.options, rand)
			table.insert(_G.tot_dam_list, rand)
			table.insert(_G.tot_dam_list_index, i)
		end
		
	end
	list_to_global(_G.list_of_tiles_done, "list_of_tiles_done_glo")
	list_to_global(_G.options,'options_glo')
	list_to_global(_G.options_type,'options_type_glo')
	list_to_global(_G.objective_list,'objective_list_glo')
	list_to_global(_G.objective_list_index,'objective_list_index_glo')
	list_to_global(_G.biome_list,'biome_list_glo')
	list_to_global(_G.biome_list_index,'biome_list_index_glo')
	list_to_global(_G.perk_lists,'perk_lists_glo')
	list_to_global(_G.perk_lists_index,'perk_lists_index_glo')
	list_to_global(_G.status_lists,'status_lists_glo')
	list_to_global(_G.status_lists_index,'status_lists_index_glo')
	list_to_global(_G.kill_count,'kill_count_glo')
	list_to_global(_G.kill_count_index,'kill_count_index_glo')
	list_to_global(_G.gold_count,'gold_count_glo')
	list_to_global(_G.gold_count_index,'gold_count_index_glo')
	list_to_global(_G.max_hp_count,'max_hp_count_glo')
	list_to_global(_G.max_hp_count_index,'max_hp_count_index_glo')
	list_to_global(_G.curr_hp_count,'curr_hp_count_glo')
	list_to_global(_G.curr_hp_count_index,'curr_hp_count_index_glo')
	list_to_global(_G.orb_number,'orb_number_glo')
	list_to_global(_G.orb_number_index,'orb_number_index_glo')
	list_to_global(_G.stat_list,'stat_list_glo')
	list_to_global(_G.stat_list_index,'stat_list_index_glo')
	list_to_global(_G.trick_kill_list,'trick_kill_list_glo')
	list_to_global(_G.trick_kill_list_index,'trick_kill_list_index_glo')
	list_to_global(_G.spell_lists,'spell_lists_glo')
	list_to_global(_G.spell_lists_index,'spell_lists_index_glo')
	list_to_global(_G.spent_list,'spent_list_glo')
	list_to_global(_G.spent_list_index,'spent_list_index_glo')
	list_to_global(_G.bought_list,'bought_list_glo')
	list_to_global(_G.bought_list_index,'bought_list_index_glo')
	list_to_global(_G.tot_dam_list,'tot_dam_list_glo')
	list_to_global(_G.tot_dam_list_index,'tot_dam_list_index_glo')
end