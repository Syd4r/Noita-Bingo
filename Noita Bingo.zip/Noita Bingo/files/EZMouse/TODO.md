[ ] Quantization + Keeping aspect ratio
