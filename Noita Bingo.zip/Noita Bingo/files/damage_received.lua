max_dam_taken = {}

function list_to_global(list_name,global_name)
	local placeholder = ""
	for _,i in ipairs(list_name) do
		placeholder = placeholder..tostring(i)..","
	end
	GlobalsSetValue(global_name,placeholder)
end

function mysplit (inputstr, sep)
	local t={}
	for str in string.gmatch(inputstr, "([^"..sep.."]+)") do
		table.insert(t, str)
	end
	return t
end

function all_list_to_int(list_thing)
	local inc = 0
	for _,i in ipairs(list_thing) do
		inc = inc + 1
		list_thing[inc] = tonumber(i)
	end
	return list_thing
end

function update_globals(list_of_tiles_doned,list_list,index_list,str_name,inc)
	list_of_tiles_doned[index_list[inc]] = not list_of_tiles_doned[index_list[inc]]
	list_to_global(list_of_tiles_doned,'list_of_tiles_done_glo')
	table.remove(list_list,inc)
	table.remove(index_list,inc)
	list_to_global(list_list, str_name..'_glo')
	list_to_global(index_list, str_name..'_index_glo')
	return list_of_tiles_doned,list_list,index_list
end

function if_dam_taken(list_of_tiles_done,dam_taken_list,tot_dam_list_index,tot_dam)
	inc = 0
	for i,j in ipairs(dam_taken_list) do
		inc = inc + 1
		if (j <= tot_dam) then
			GamePrint("Took "..j.." total damage")
			list_of_tiles_done,dam_taken_list,tot_dam_list_index = update_globals(list_of_tiles_done,dam_taken_list,tot_dam_list_index,"tot_dam_list",inc)
		end
	end
end

function if_max_dam_taken(max_dam_taken,damage)
	for i,j in ipairs(max_dam_taken) do
		if (j <= damage) then
			GamePrint("Hit for "..j.." damage")
			table.remove(max_dam_taken,1)
		end
	end
end

function damage_received( damage, message, _entity_thats_responsible, _is_fatal, _projectile_thats_responsible )
    local tot_dam = GlobalsGetValue("tot_dam_taken") + (damage*25)
	GlobalsSetValue("tot_dam_taken",tot_dam)
	_G.tot_dam_list = all_list_to_int(mysplit(GlobalsGetValue('tot_dam_list_glo'), ","))
	_G.tot_dam_list_index = all_list_to_int(mysplit(GlobalsGetValue('tot_dam_list_index_glo'), ","))
	_G.list_of_tiles_done = mysplit(GlobalsGetValue('list_of_tiles_done_glo'), ",")
		local inc = 0
		for _,i in ipairs(_G.list_of_tiles_done) do
			inc = inc + 1
			if i == 'true' then
				list_of_tiles_done[inc] = true
			else
				list_of_tiles_done[inc] = false
			end
		end
	if #_G.tot_dam_list > 0 then if_dam_taken(_G.list_of_tiles_done,_G.tot_dam_list,_G.tot_dam_list_index,tot_dam) end
	if #max_dam_taken > 0 then if_max_dam_taken(max_dam_taken,damage*25) end
end