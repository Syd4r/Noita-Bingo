dofile_once("data/scripts/lib/utilities.lua")
dofile_once("data/scripts/gun/gun.lua")
dofile_once("data/scripts/status_effects/status_list.lua")

modName = "Noita Bingo"
check_list = {}
check_list_2 = {}

dofile_once("mods/"..modName.."/files/variables.lua")
EZWand = dofile_once("mods/"..modName.."/files/EZWand.lua")

function list_to_global(list_name,global_name)
	local placeholder = ""
	for _,i in ipairs(list_name) do
		placeholder = placeholder..i..","
	end
	GlobalsSetValue(global_name,placeholder)
end


function greater_less(val1,great_less,val2)
	if great_less == ">" then
		return(val1 > val2)
	else
		return(val1 < val2)
	end
end

function mysplit (inputstr, sep)
	local t={}
	for str in string.gmatch(inputstr, "([^"..sep.."]+)") do
		table.insert(t, str)
	end
	return t
end

function update_globals(list_of_tiles_doned,list_list,index_list,str_name,inc)
	list_of_tiles_doned[index_list[inc]] = not list_of_tiles_doned[index_list[inc]]
	list_to_global(list_of_tiles_doned,'list_of_tiles_done_glo')
	table.remove(list_list,inc)
	table.remove(index_list,inc)
	list_to_global(list_list, str_name..'_glo')
	list_to_global(index_list, str_name..'_index_glo')
	return list_of_tiles_doned,list_list,index_list
end

function EntityGetInRadiusWithNames(objective_list, tag)
	--objective_list: list, tag: "string", output: {entity_ids}, {names}
	local player = EntityGetWithTag("player_unit")[1]
	local x, y = EntityGetTransform(player)
	local r = 175
	local good_list = {}
	local enemy_names = {}
	if tag == "boss" then
		all_enemies = EntityGetWithTag(tag)
	else
		all_enemies = EntityGetInRadiusWithTag(x,y,r,tag)
	end
	for _,i in ipairs(all_enemies) do
		local entity_name = EntityGetName(i)
		for _,j in ipairs(objective_list) do
			if entity_name == j then
				table.insert(good_list,i)
				table.insert(enemy_names,entity_name)
			end
		end
	end
	return good_list, enemy_names
end



function EnemyInRadiusGetIsAlive(objective_list, tag, check_thing)
	--I am not proud of my implementation of enemies and bosses together, please forgive me
	--objective_list: list, tag: "string", output: {names}
	local inc = 1
	local all_dead = {}
	for _,i in ipairs(check_thing) do
		if EntityGetIsAlive(i) == false then
			if tag == "homing_target" then
				table.insert(all_dead, enemy_name_list[inc])
			else
				table.insert(all_dead, enemy_name_list_2[inc])
			end
		end
		inc = inc + 1
	end
	if tag == "homing_target" then
		check_list,enemy_name_list = EntityGetInRadiusWithNames(objective_list, tag)
	else
		check_list_2,enemy_name_list_2 = EntityGetInRadiusWithNames(objective_list, tag)
	end
	return all_dead
end


function enemy_names_killed_check(list_of_tiles_done,objective_list,objective_list_index)
	local current_death = EnemyInRadiusGetIsAlive(objective_list, "homing_target", check_list)
	for _,j in ipairs(current_death) do
		local inc = 0
		for _,i in ipairs(objective_list) do
			inc = inc + 1
			if j == i then
				GamePrint("Killed "..j.." enemy")
				list_of_tiles_done,objective_list,objective_list_index = update_globals(list_of_tiles_done,objective_list,objective_list_index,"objective_list",inc)
				check_list = {}
			end
		end
	end
end

function moved_into_biome(list_of_tiles_done,biome_list,biome_list_index)
	local inc = 0
	local player = EntityGetWithTag("player_unit")[1]
	local x, y = EntityGetTransform(player)
	local currbiome = BiomeMapGetName( x, y )
	for _,i in ipairs(biome_list) do
		inc = inc + 1
		if i == tostring(currbiome) then
			list_of_tiles_done,biome_list,biome_list_index = update_globals(list_of_tiles_done,biome_list,biome_list_index,"biome_list",inc)
			GamePrint("Visted ".. i .. " biome")
		end
	end
end


function picked_up_perk(list_of_tiles_done,perk_lists,perk_lists_index)
	local inc = 0
	for _,i in ipairs(perk_lists) do
		inc = inc + 1
		if GameHasFlagRun("PERK_PICKED_" .. i) then
			list_of_tiles_done,perk_lists,perk_lists_index = update_globals(list_of_tiles_done,perk_lists,perk_lists_index,"perks_list",inc)
			GamePrint("Picked up "..i.." perk")
		end
	end
end

function killed_boss(list_of_tiles_done,boss_list,boss_list_index)
	local current_death = EnemyInRadiusGetIsAlive(boss_list, "boss", check_list_2)
	for _,j in ipairs(current_death) do
		local inc = 0
		for _,i in ipairs(boss_list) do
			inc = inc + 1
			if j == i then
				GamePrint("Killed "..j.." boss")
				list_of_tiles_done,boss_list,boss_list_index = update_globals(list_of_tiles_done,boss_list,boss_list_index,"boss_list",inc)
				check_list_2 = {}
			end
		end
	end
end

function has_status(list_of_tiles_done,status_lists,status_lists_index)
	local inc = 1
	local player = EntityGetWithTag("player_unit")[1]
	local status_effect_data_component = EntityGetFirstComponentIncludingDisabled(player, "StatusEffectDataComponent")
	local stain_effects = ComponentGetValue2(status_effect_data_component, "stain_effects")
	if stain_effects ~= nil then
		for k,v in pairs(stain_effects) do
			if v > 0 then
				local status_effect_id = status_effects[k-1].id
				local inc = 0
				for _,i in ipairs(status_lists) do
					inc = inc + 1
					if status_effect_id == i then
						list_of_tiles_done,status_lists,status_lists_index = update_globals(list_of_tiles_done,status_lists,status_lists_index,"status_lists",inc)
						GamePrint("Got "..i.." effect")
					end
				end
			end
		end
	end
end

function total_kills_equal(list_of_tiles_done,kill_count,kill_count_index)
	local inc = 0
	for _,i in ipairs(kill_count) do
		inc = inc + 1
		if tonumber(StatsGetValue("enemies_killed")) >= tonumber(i) then
			GamePrint("Killed "..i.." enemies")
			list_of_tiles_done,kill_count,kill_count_index = update_globals(list_of_tiles_done,kill_count,kill_count_index,"kill_count",inc)
		end
	end
end

function total_gold_equal(list_of_tiles_done,gold_count,gold_count_index)
	local player = EntityGetWithTag("player_unit")[1]
	local inc = 0
	if player ~= nil then
		local comp = EntityGetComponent(player,"InventoryGuiComponent")[1]
		local curr_gold = ComponentGetValue2(comp, "wallet_money_target")
		GlobalsSetValue("curr_gold_glo",curr_gold)
		for _,i in ipairs(gold_count) do
			inc = inc + 1
			if curr_gold >= tonumber(i) then
				GamePrint("Got "..i.." gold")
				list_of_tiles_done,gold_count,gold_count_index = update_globals(list_of_tiles_done,gold_count,gold_count_index,"gold_count",inc)
			end
		end
	end
end

function max_health_equals(list_of_tiles_done,max_hp_count,max_hp_count_index,max_or_curr)
	local player = EntityGetWithTag("player_unit")[1]
	local dmgmodel = EntityGetFirstComponentIncludingDisabled(player, "DamageModelComponent")
	local inc = 0
	if dmgmodel ~= nil then
		local max_hpp = math.floor(25*tonumber(ComponentGetValue2(dmgmodel, max_or_curr) or 0))
		for _,i in ipairs(max_hp_count) do
			inc = inc + 1
			if max_or_curr == "max_hp" then
				GlobalsSetValue("gui_stuff_for_max_hp",max_hpp)
				if max_hpp >= tonumber(i) then
					GamePrint("Have "..i.. max_or_curr)
					list_of_tiles_done,max_hp_count,max_hp_count_index = update_globals(list_of_tiles_done,max_hp_count,max_hp_count_index,"max_hp_count",inc)
				end
			else
				if max_hpp == tonumber(i) then
					GamePrint("Have "..i.. max_or_curr)
					list_of_tiles_done,max_hp_count,max_hp_count_index = update_globals(list_of_tiles_done,max_hp_count,max_hp_count_index,"curr_hp_count",inc)
				end
			end
		end
	end
end

function orb_count_equal(list_of_tiles_done,orb_number,orb_number_index)
	local orb_count = GameGetOrbCountThisRun()
	local inc = 0
	if orb_count ~= nil then
		for _,i in ipairs(orb_number) do
			inc = inc + 1
			if orb_count >= tonumber(i) then
				GamePrint("Have "..i.. " orbs")
				list_of_tiles_done,orb_number,orb_number_index = update_globals(list_of_tiles_done,orb_number,orb_number_index,"orb_number",inc)
			end
		end
	end
end

function if_killed_by(death_message)
	local curr_death = StatsGetValue("killed_by")
	local curr_death_extra = StatsGetValue("killed_by_extra")
	local tot_death = curr_death..curr_death_extra
	local inc = 0
	for _,i in ipairs(death_message) do
		inc = inc + 1
		if tot_death == i then
			GamePrint("Died by "..i)
			table.remove(death_message,inc)
		end
	end
end

function if_wand_has_stats(list_of_tiles_done,stat_list,stat_list_index)
	local wand = EZWand.GetHeldWand()
	local inc = 0
	for _,i in ipairs(stat_list) do
		inc = inc + 1
		local what_stat = mysplit(i,"|")
		if wand then
			if what_stat[1] == "spellscast" then
				val1 = (wand.spellsPerCast)
			elseif what_stat[1] == "castdelay" then
				val1 = (wand.castDelay*10/6)
			elseif what_stat[1] == "rechargetime" then
				val1 = (wand.rechargeTime*10/6)
			elseif what_stat[1] == "manamax" then
				val1 = (wand.manaMax)
			elseif what_stat[1] == "maxchargespeed" then
				val1 = (wand.manaChargeSpeed)
			elseif what_stat[1] == "capacity" then
				val1 = (wand.capacity)
			elseif what_stat[1] == "spread" then
				val1 = (wand.spread)
			end
			if(greater_less(val1,what_stat[2],tonumber(what_stat[3]))) then
				GamePrint("Wand has "..what_stat[1].." "..what_stat[2].." "..what_stat[3])
				list_of_tiles_done,stat_list,stat_list_index = update_globals(list_of_tiles_done,stat_list,stat_list_index,"stat_list",inc)
			
			end
		end
	end
end

function if_item_found(item_list)
	local player = EntityGetWithTag("player_unit")[1]
	local x, y = EntityGetTransform(player)
	local r = 165
	local items_id = EntityGetInRadiusWithTag(x,y,r,"item_pickup")
	for _,i in ipairs(items_id) do
		if i ~= nil then
			local compp = EntityGetFirstComponentIncludingDisabled(i, "ItemComponent")
			local item_named = ComponentGetValue2(compp, "item_name")
			local inc = 0
			for _,j in ipairs(item_list) do
				inc = inc + 1
				if item_named == j then
					GamePrint("Found item "..j)
					table.remove(item_list,inc)
				end
			end
		end
	end
end

function num_trick_kills(list_of_tiles_done,trick_kill_list,trick_kill_list_index)
	local total_num_tricks = GlobalsGetValue("tot_trick_kills")
	local inc = 0
	if total_num_tricks ~= nil then
		for _,i in ipairs(trick_kill_list) do
			inc = inc + 1
			if tonumber(i) <= tonumber(total_num_tricks) then
				GamePrint("Got trick kills")
				list_of_tiles_done,trick_kill_list,trick_kill_list_index = update_globals(list_of_tiles_done,trick_kill_list,trick_kill_list_index,"trick_kill_list",inc)
			
			end
		end
	end
end