dofile("data/scripts/lib/mod_settings.lua") -- see this file for documentation on some of the features.

function mod_setting_change_callback( mod_id, gui, in_main_menu, setting, old_value, new_value  )
	print( tostring(new_value) )
end

local mod_id = "noita_bingo"
mod_settings_version = 1 
mod_settings = 
{
	{
		id = "difficulty_level",
		ui_name = "Bingo Difficulty",
		ui_description = "Select the bingo difficulty",
		value_default = "normal",
		values = {
			{"easy", "Easy Mode"},
			{"normal","Normal Mode"},
			{"hard","Hard Mode"},
		},
		scope = MOD_SETTING_SCOPE_RUNTIME, 
	},
	{
		id = "bingo_type",
		ui_name = "Bingo Type",
		ui_description = "Select how you get a bingo",
		value_default = "line",
		values = {
			{"line","Line Mode"},
			{"full","Full Board Mode"},
		},
		scope = MOD_SETTING_SCOPE_RUNTIME, 
	},
	{
		id = "reward",
		ui_name = "Reward Type",
		ui_description = "Select the reward when you get a bingo",
		value_default = "great",
		values = {
			{"great","Great Treasure Chest"},
			{"chest","Treasure Chest"},
			{"sun","Sun"},
			{"none","None"},
		},
		scope = MOD_SETTING_SCOPE_RUNTIME, 
	},
	{
		id = "gui",
		ui_name = "Bingo Button Location",
		ui_description = "Choose where the open bingo button is located at",
		value_default = "middle",
		values = {
			{"left","Top Left Corner"},
			{"middle","Top Middle"},
			{"right","Top Right Corner"},
		},
		scope = MOD_SETTING_SCOPE_RUNTIME, 
	},
}
function ModSettingsUpdate( init_scope )
	local old_version = mod_settings_get_version( mod_id )
	mod_settings_update( mod_id, mod_settings, init_scope )
end

function ModSettingsGuiCount()
	return mod_settings_gui_count( mod_id, mod_settings )
end

function ModSettingsGui( gui, in_main_menu )
	mod_settings_gui( mod_id, mod_settings, gui, in_main_menu )
end
