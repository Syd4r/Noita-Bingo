dofile( "data/scripts/game_helpers.lua" )

function list_to_global(list_name,global_name)
	local placeholder = ""
	for _,i in ipairs(list_name) do
		placeholder = placeholder..tostring(i)..","
	end
	GlobalsSetValue(global_name,placeholder)
end

function mysplit (inputstr, sep)
	local t={}
	for str in string.gmatch(inputstr, "([^"..sep.."]+)") do
		table.insert(t, str)
	end
	return t
end

function all_list_to_int(list_thing)
	local inc = 0
	for _,i in ipairs(list_thing) do
		inc = inc + 1
		list_thing[inc] = tonumber(i)
	end
	return list_thing
end

function update_globals(list_of_tiles_doned,list_list,index_list,str_name,inc)
	list_of_tiles_doned[index_list[inc]] = not list_of_tiles_doned[index_list[inc]]
	list_to_global(list_of_tiles_doned,'list_of_tiles_done_glo')
	table.remove(list_list,inc)
	table.remove(index_list,inc)
	list_to_global(list_list, str_name..'_glo')
	list_to_global(index_list, str_name..'_index_glo')
	return list_of_tiles_doned,list_list,index_list
end

function if_spent_amount(list_of_tiles_done,list_of_gold_spent,list_of_gold_spent_index,entity_item)
	local compp = EntityGetFirstComponentIncludingDisabled(entity_item, "ItemCostComponent")
	local costy = ComponentGetValue2(compp, "cost")
	tot_spent = GlobalsGetValue("tot_gold_spent")
	GlobalsSetValue("tot_gold_spent",tot_spent + costy)
	local inc = 0
	for _,j in ipairs(list_of_gold_spent) do
		inc = inc + 1
		if (tonumber(j) <= tonumber(tot_spent + costy)) then
			GamePrint("Spent "..j.." gold")
			list_of_tiles_done,list_of_gold_spent,list_of_gold_spent_index = update_globals(list_of_tiles_done,list_of_gold_spent,list_of_gold_spent_index,"spent_list",inc)
		end
	end
end

function if_things_bought(list_of_tiles_done,list_things_bought,bought_list_index)
	tot_bought = GlobalsGetValue("tot_things_bought")
	GlobalsSetValue("tot_things_bought",tot_bought + 1)
	inc = 0
	for _,j in ipairs(list_things_bought) do
		inc = inc + 1
		if (j <= tot_bought+1) then
			GamePrint("Buy "..j.." things")
			list_of_tiles_done,list_things_bought,bought_list_index = update_globals(list_of_tiles_done,list_things_bought,bought_list_index,"bought_list",inc)
		end
	end
end

function item_pickup( entity_item, entity_who_picked, name )
	local x, y = EntityGetTransform( entity_item )
	_G.spent_list = all_list_to_int(mysplit(GlobalsGetValue('spent_list_glo'), ","))
	_G.spent_list_index = all_list_to_int(mysplit(GlobalsGetValue('spent_list_index_glo'), ","))
	_G.bought_list = all_list_to_int(mysplit(GlobalsGetValue('bought_list_glo'), ","))
	_G.bought_list_index = all_list_to_int(mysplit(GlobalsGetValue('bought_list_index_glo'), ","))
	_G.list_of_tiles_done = mysplit(GlobalsGetValue('list_of_tiles_done_glo'), ",")
		local inc = 0
		for _,i in ipairs(_G.list_of_tiles_done) do
			inc = inc + 1
			if i == 'true' then
				list_of_tiles_done[inc] = true
			else
				list_of_tiles_done[inc] = false
			end
		end
	if #_G.spent_list > 0 then if_spent_amount(_G.list_of_tiles_done,_G.spent_list,_G.spent_list_index, entity_item) end
	if #_G.bought_list > 0 then if_things_bought(_G.list_of_tiles_done,_G.bought_list,_G.bought_list_index) end
	EntityLoad("data/entities/particles/image_emitters/shop_effect.xml", x, y-8)
end
 
 